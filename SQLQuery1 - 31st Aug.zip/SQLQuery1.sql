use hrms 


select * from C_Employee
select * into C_Employee_copy from C_Employee


select * from C_Employee_copy
select * from  C_Employee

--union 
select * from C_Employee_copy
union
select * from  C_Employee

--union ALL 
select * from C_Employee_copy
union ALL 
select * from  C_Employee



---Join : to merge two or more than two table horizentally 
--at least one column should be same (logically) in all sources
select * from  C_Employee
select * from  j_salary

--Types of join : 
 -- i. inner join   / equi join / default join 
 -- ii. outer join/full outer join 
 -- iii. left join / full outer join 
 --  iv. right join / full outer join 

 --i. inner join   / equi join / default join  : return common/matching rows

 select C_Employee.EmpID , C_Employee.EmpName, C_Employee.Address,j_salary.sal
 from C_Employee inner join j_salary 
	on  C_Employee.EmpId = j_salary.id


	select C_Employee.EmpID , C_Employee.EmpName, C_Employee.Address,j_salary.sal
 from C_Employee join j_salary 
	on  C_Employee.EmpId = j_salary.id

	-- iii. left join / full outer join  : return all rows from left table and matching from right table
 select C_Employee.EmpID , C_Employee.EmpName, C_Employee.Address,j_salary.sal
 from C_Employee left join j_salary 
	on  C_Employee.EmpId = j_salary.id

select C_Employee.EmpID , C_Employee.EmpName, C_Employee.Address,j_salary.sal
 from C_Employee left  outer join j_salary 
	on  C_Employee.EmpId = j_salary.id

--  iv. right join / full outer join  : return all rows from right table and matching from left table 

select C_Employee.EmpID , C_Employee.EmpName, C_Employee.Address,j_salary.sal
 from C_Employee right  join j_salary 
	on  C_Employee.EmpId = j_salary.id 

	
select C_Employee.EmpID , C_Employee.EmpName, C_Employee.Address,j_salary.sal
 from C_Employee right outer join j_salary 
	on  C_Employee.EmpId = j_salary.id 

-- ii. outer join/full outer join  : return all rows from all tables 

select C_Employee.EmpID , C_Employee.EmpName, C_Employee.Address,j_salary.sal
 from C_Employee full outer join j_salary 
	on  C_Employee.EmpId = j_salary.id 


--Functions
---------------------------------------------
---------------------------------------------
--Aggregiate function  : summarize function 
--max, min, count, avg , sum 

select max(empid) from C_Employee
select min(empid) from C_Employee
select sum(empid) from C_Employee
select avg(empid) from C_Employee
select count(empid) from C_Employee

select count(empid),max(empid), min(empid) from C_Employee

hs es cs ms 
--sum(hs,es,cs,ms)
hs+es+cs+ms

sum(hs)
--maths function 
select sqrt(100), power(3,5), ROUND(44445.333,2)

---date function 
select getdate()  --yyyy-mm-dd
select DATEPART(yyyy,getdate())
select DATEPART(mm,getdate())
select DATEPART(DAYOFYEAR,getdate())
select DATEPART(WEEK,getdate())
select DATEPART(QUARTER,getdate())
select DATEPART(WEEKDAY ,getdate())

select DATEDIFF(yyyy,'1990-11-30',getdate())
select DATEDIFF(DAY,'1990-11-30',getdate())
select DATEDIFF(MONTH,'1990-11-30',getdate())
select DATEDIFF(HOUR,'1990-11-30',getdate())

select dateadd(dd,10,getdate())

--text function 
select * from c_employee

select *, left(empname,4) from c_employee
select *, right(empname,4) from c_employee
select *, len(empname) from c_employee

select *, replace(empname,'a','xy') from c_employee


select *, upper(empname) from c_employee
select *, lower(empname) from c_employee


select *, ltrim(empname) from c_employee  --remove extra space from left 
select *, rtrim(empname) from c_employee


/*
View   :  is virtual table which contains structure but data 
	   : view can be use a physical table table 
*/

--create view 
create view emp_details 
as
 select C_Employee.EmpID , C_Employee.EmpName, C_Employee.Address,j_salary.sal
 from C_Employee inner join j_salary 
	on  C_Employee.EmpId = j_salary.id



create view all_data
as
	select * from C_Employee_copy
	union all 
	select * from  C_Employee
	union all
	select * from  C_Employee
	union all
	select * from  C_Employee
	union all 
	select * from  C_Employee
	union all 
	select * from  C_Employee





select * from emp_details  

select * from all_data 



--stored procedure :  is precompiled code which is reusable 
create  procedure tbl_action 
as
begin
		
		delete from c_employee where empid =11 

		update  c_employee set EmpName ='abce' where empid =5 

		select * from C_Employee

		select * from j_salary


		select C_Employee.EmpID , C_Employee.EmpName, C_Employee.Address,j_salary.sal
		 from C_Employee inner join j_salary 
			on  C_Employee.EmpId = j_salary.id


end



execute tbl_action 

---
select * from new_sal ;


if exists(select * from new_sal where emp_code = 1999)
begin
		select 'match'
end	
else
begin
		select 'not match'
end
